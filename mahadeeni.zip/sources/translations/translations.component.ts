import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-translations',
  templateUrl: './translations.component.html',
  styleUrls: ['./translations.component.scss']
})
export class TranslationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
