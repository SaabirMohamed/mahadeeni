import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendmessageformComponent } from './sendmessageform.component';

describe('SendmessageformComponent', () => {
  let component: SendmessageformComponent;
  let fixture: ComponentFixture<SendmessageformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendmessageformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendmessageformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
