import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomecaroselComponent } from './homecarosel.component';

describe('HomecaroselComponent', () => {
  let component: HomecaroselComponent;
  let fixture: ComponentFixture<HomecaroselComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomecaroselComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomecaroselComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
