import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyglobalsModule} from '../../shared/myglobals.module';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { CaroselComponent } from '../../components/carosel/carosel.component';
import { HomecaroselComponent } from './components/homecarosel/homecarosel.component';
import { ArticlestreamComponent } from './components/articlestream/articlestream.component';
import {ReverseOrder} from './reverse.pipe';
import { Ng2CarouselamosModule } from 'ng2-carouselamos';
import { AdvertsComponent } from './components/adverts/adverts.component';
import { TrackScrollDirective } from '../../shared/track-scroll.directive';

@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    MyglobalsModule,
    Ng2CarouselamosModule
  ],
  declarations: [TrackScrollDirective,
     HomeComponent, CaroselComponent, HomecaroselComponent, ArticlestreamComponent, ReverseOrder, AdvertsComponent]
})
export class HomeModule { }

