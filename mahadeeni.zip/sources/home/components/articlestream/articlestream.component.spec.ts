import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticlestreamComponent } from './articlestream.component';

describe('ArticlestreamComponent', () => {
  let component: ArticlestreamComponent;
  let fixture: ComponentFixture<ArticlestreamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticlestreamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticlestreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
