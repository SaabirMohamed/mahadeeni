import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gmap',
  templateUrl: './gmap.component.html',
  styleUrls: ['./gmap.component.scss']
})
export class GmapComponent implements OnInit {
  zoom = 8;
  // google maps zoom level
  markers: MyMarker[] = [{
    lat: 51.673858, lng: 7.815982, label: 'Mahadeeni.co.za', draggable: true }
  ];

  // initial center position for the map
  lat = 51.673858;
  lng = 7.815982;

  clickedMarker(label: string, index: number) {
    console.log(`clicked the marker: ${label || index}`);
  }

  mapClicked($event: any) {
    this.markers.push({
      lat: $event.coords.lat,
      lng: $event.coords.lng,
      draggable: true
    });
  }

  markerDragEnd(m: MyMarker, $event: MouseEvent) {
    console.log('dragEnd', m, $event);
  }



  ngOnInit(): void {
  }
}

// just an interface for type safety.
interface MyMarker {lat: number; lng: number; label?: string; draggable: boolean;
}

