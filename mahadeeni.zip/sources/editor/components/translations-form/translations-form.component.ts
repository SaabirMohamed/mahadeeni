import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-translations-form',
  templateUrl: './translations-form.component.html',
  styleUrls: ['./translations-form.component.scss']
})
export class TranslationsFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
