import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'reverse', pure: false})
export class ReverseOrder implements PipeTransform {
  transform(values: any): any {
    return values.reverse();
  }
}
