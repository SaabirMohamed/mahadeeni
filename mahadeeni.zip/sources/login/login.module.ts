import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyglobalsModule} from '../../shared/myglobals.module';
// import { AuthguardGuard } from '../authguard.guard';
import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { SocialsComponent } from '../../components/socials/socials.component';
import { AngularFireAuthModule, AngularFireAuth } from 'angularfire2/auth';

@NgModule({
  imports: [
    CommonModule,
    MyglobalsModule,
    LoginRoutingModule,
    AngularFireAuthModule

  ],
  declarations: [LoginComponent, SocialsComponent],
  providers: [AngularFireAuth]
})
export class LoginModule { }
