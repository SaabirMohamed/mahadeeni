import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { AngularFirestore, AngularFirestoreDocument, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Page } from '../../../../shared/page.model';

@Component({
  selector: 'app-homecarosel',
  templateUrl: './homecarosel.component.html',
  styleUrls: ['./homecarosel.component.scss']
})
export class HomecaroselComponent  {

bannershow: boolean;

items: Array<BannerItem>;
  constructor() {
    this.items = [
      { bannerImage: 'ramadaanevents.jpg', bannerText: '', btnText: '', btnAction: 'events'},
      { bannerImage: 'school.jpg', bannerText: '', btnText: '', btnAction: 'school'},
      { bannerImage: 'meetupflyer.jpg', bannerText: '', btnText: '', btnAction: 'events'},
      { bannerImage: 'education.png', bannerText: '', btnText: '', btnAction: 'education'},


        ];
        setTimeout(data => {
          this.bannershow = true;
      }, 1000);
  }



}

export interface BannerItem {
  bannerImage: string;
  bannerText: string;
  btnText: string;
  btnAction: string;
}

