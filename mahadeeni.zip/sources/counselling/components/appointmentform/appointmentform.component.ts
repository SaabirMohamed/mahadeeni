import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointmentform',
  templateUrl: './appointmentform.component.html',
  styleUrls: ['./appointmentform.component.scss']
})
export class AppointmentformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
