import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MyglobalsModule} from '../../shared/myglobals.module';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { ControlpanelRoutingModule } from './controlpanel-routing.module';
// import { ControlpanelComponent } from './controlpanel.component';



@NgModule({
  imports: [
    CommonModule,
    MyglobalsModule,
    ControlpanelRoutingModule,
    MDBBootstrapModule.forRoot()
  ],
  declarations: []
})
export class ControlpanelModule { }
