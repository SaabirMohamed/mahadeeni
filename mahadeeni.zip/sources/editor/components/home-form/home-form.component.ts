import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { FsService } from '../../../../shared/fs.service';
import { Page } from '../../../../shared/page.model';

@Component({
  selector: 'app-home-form',
  templateUrl: './home-form.component.html',
  styleUrls: ['./home-form.component.scss']
})
export class HomeFormComponent implements OnInit {
  dociId = 'homepage';
  colId = 'modules';
  pageTitleForm: FormGroup;
  pageSubTitleForm: FormGroup;
  pageImageForm: FormGroup;
  payload: any;
  currentFileName: 'defaultlogo.png';
  currentFileToUpload: File;

  constructor(private fbsvc: FsService, public fbuilder: FormBuilder) {
    this.pageTitleForm = this.fbuilder.group({
      pageTitle: ['', Validators.required]
    });

    this.pageSubTitleForm = this.fbuilder.group({
      pageSubTitle: ['', Validators.required]
    });

    this.pageImageForm = this.fbuilder.group({
      pageImage: ['', Validators.required]
    });

   }

  ngOnInit() {
    // this.pageTitleForm = new FormGroup({
    //   pageTitle: new FormControl('', {
    //     validators: Validators.required,
    //     updateOn: 'change'
    //   })
    // });

    // this.pageSubTitleForm = new FormGroup({
    //   pageSubTitle: new FormControl('', {
    //     validators: Validators.required,
    //     updateOn: 'change'
    //   })
    // });
    // this.pageImageForm =  new FormGroup({
    //   pageImage: new FormControl('', {
    //     validators: Validators.required,
    //     updateOn: 'change'
    //   })
    // });
  }

  updateTitle(val) {
      if (val !== '') {
        document.getElementById('titleBtn').setAttribute('style', 'opacity:0.1');
        const payload = {
          pageTitle : val
        };
        // this.fbsvc.updateDocument('modules', 'homepage', <Page>payload) (testing)
        this.fbsvc.updateDocument(this.colId, this.dociId, <Page>payload)
        .then((data) => {
                this.pageTitleForm.reset();
                document.getElementById('titleBtn').setAttribute('style', 'opacity:1');
              })
        .catch((error) => console.log(error));
      } else {
        document.getElementById('titleBtn').setAttribute('style', 'opacity:1');
        return;
      }
  }

  updateSubTitle(val) {
    document.getElementById('subtitleBtn').setAttribute('style', 'opacity:0');
    if (val !== '') {
     const payload = {
      pageSubTitle : val
    };
    // this.fbsvc.updateDocument('modules', 'homepage', <Page>payload)
    this.fbsvc.updateDocument(this.colId, this.dociId, <Page>payload)
    .then(data => {
      this.pageSubTitleForm.reset();
      document.getElementById('subtitleBtn').setAttribute('style', 'opacity:1');
    } )
    .catch((error) => console.log(error));
  }
}

  updatePageImage() {
    document.getElementById('uploadBtn').setAttribute('style', 'opacity:0');
    this.uploadToServer();
     const payload = {
      pageImage : this.currentFileName
    };
    this.fbsvc.updateDocument('modules', 'homepage', payload)
    //  this.fbsvc.updateDocument(this.dociId, this.dociId, <Page>payload)
    .then(data => {
      document.getElementById('uploadBtn').setAttribute('style', 'opacity:1');
      this.pageImageForm.reset();
      this.currentFileName = null;

    })
    .catch((error) => console.log(error));
  }

  ProcessFile(event) {
    console.log(event.target.files[0].name);
    this.currentFileName = event.target.files[0].name;
    this.currentFileToUpload = event.target.files[0];
  }

  uploadToServer() {
    console.log('will be uploading this: ' + this.currentFileToUpload);
    this.fbsvc.AddToServerAssets(this.currentFileToUpload);
  }

}
