import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyglobalsModule } from '../../shared/myglobals.module';
import { EditorRoutingModule } from './editor-routing.module';
import { EditorComponent } from './editor.component';
import { HomeFormComponent } from './components/home-form/home-form.component';
import { ArticlesFormComponent } from './components/articles-form/articles-form.component';
import { SchoolFormComponent } from './components/school-form/school-form.component';
import { CounsellingFormComponent } from './components/counselling-form/counselling-form.component';
import { AboutFormComponent } from './components/about-form/about-form.component';
import { TranslationsFormComponent } from './components/translations-form/translations-form.component';
import { ContactsFormComponent } from './components/contacts-form/contacts-form.component';
import { HttpClient } from '@angular/common/http';

@NgModule({
  imports: [
    CommonModule,
    EditorRoutingModule,
    MyglobalsModule
  ],
  declarations: [
     EditorComponent,
     HomeFormComponent,
     ArticlesFormComponent,
     SchoolFormComponent,
     CounsellingFormComponent, AboutFormComponent, TranslationsFormComponent, ContactsFormComponent],
     providers: [HttpClient]
})
export class EditorModule { }
