import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate} from '@angular/router';
// import { AuthguardGuard } from '../authguard.guard';
import { LoginComponent } from './login.component';
import { MyglobalsModule } from '../../shared/myglobals.module';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent
      }
];

@NgModule({
  imports: [RouterModule.forChild(routes), MyglobalsModule, MDBBootstrapModule],
  exports: [RouterModule]
})
export class LoginRoutingModule { }
