import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sendmessageform',
  templateUrl: './sendmessageform.component.html',
  styleUrls: ['./sendmessageform.component.scss']
})
export class SendmessageformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
