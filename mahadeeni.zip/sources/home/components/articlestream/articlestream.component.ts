import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Observable } from 'rxjs/observable';

@Component({
  selector: 'app-articlestream',
  templateUrl: './articlestream.component.html',
  styleUrls: ['./articlestream.component.scss']
})
export class ArticlestreamComponent implements OnInit {

  articlesCollection: AngularFirestoreCollection<IArticle>;
  $articlesCollection: IArticle[];
  constructor(private router: Router, private afs: AngularFirestore) { }

  ngOnInit() {
    this.getArticles();
  }

  Navigate(path: string) {
    this.router.navigateByUrl(path);
  }
  public getArticles() {
    this.articlesCollection = this.afs.collection('modules/homepage/articles');
    this.articlesCollection.valueChanges().subscribe((data) => {
      this.$articlesCollection = data;
      console.log(this.$articlesCollection);
    });
  }


}

export interface IArticle {
  articleTitle: string;
  articleSubTile: string;
  articleImage: string;
}
