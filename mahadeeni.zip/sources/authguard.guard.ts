import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { FsService } from '../shared/fs.service';

@Injectable()
export class AuthguardGuard implements CanActivate {
  constructor(public auth: FsService, public router: Router) {}

  canActivate(): boolean {
    if (!this.auth.getLoginStatus()) {
      this.router.navigate(['login']);
      return false;
    }
    return true;
  }
}
