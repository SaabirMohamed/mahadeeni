import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFireAuth } from 'angularfire2/auth';
import { Observable } from 'rxjs/observable';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  uname: string;
  pwd: string;
  isChecking: boolean;
  isAuth: User;
  loginerrors: boolean;
  constructor(private router: Router, private afauth: AngularFireAuth) { }
  isloggedIn: boolean;
  loginerrorstext: string;
  hiddenStyle: string;
  ngOnInit() {
    this.isChecking = true;
    // this.afauth.authState.subscribe(state => {
    //   this.isAuth = state;
    //   if (this.isAuth) {
    //       this.router.navigateByUrl('/home');
    //   }
    // });
    if (localStorage.getItem('in') === '1') {
      this.isloggedIn = true;
      this.router.navigateByUrl('/editor');
    } else {
      localStorage.setItem('in', '0');
      this.isloggedIn = false;
    }
    this.isChecking = false;
  }
  login() {
    document.getElementsByClassName('theform')[0].setAttribute('style', 'opacity:0.5 !important');
    if (this.uname !== '' && this.pwd !== '') {
        this.afauth.auth.signInWithEmailAndPassword(this.uname, this.pwd)
        .then((data) => {
          // console.log(data.email);
          localStorage.setItem('in', '1');
          localStorage.setItem('uname', data.email);
          if (data.email === 'admin@mahadeeni.co.za') {
            this.router.navigateByUrl(`/editor`);
          } else {
            this.router.navigateByUrl(`/login`);
          }
        })
        .catch((error) => {
          this.loginerrors = true;
          this.loginerrorstext = error.code;
          document.getElementsByClassName('theform')[0].setAttribute('style', 'opacity:1 !important');
          localStorage.getItem('uname');
         });
    }
  }

}

export interface User {
  email: string;
}
