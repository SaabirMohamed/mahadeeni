import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-articles-form',
  templateUrl: './articles-form.component.html',
  styleUrls: ['./articles-form.component.scss']
})
export class ArticlesFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
