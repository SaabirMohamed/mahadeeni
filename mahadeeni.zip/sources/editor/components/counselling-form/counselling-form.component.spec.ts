import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CounsellingFormComponent } from './counselling-form.component';

describe('CounsellingFormComponent', () => {
  let component: CounsellingFormComponent;
  let fixture: ComponentFixture<CounsellingFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CounsellingFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CounsellingFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
