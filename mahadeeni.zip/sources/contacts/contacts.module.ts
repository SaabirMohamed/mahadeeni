import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContactsRoutingModule } from './contacts-routing.module';
import { ContactsComponent } from './contacts.component';
import { GmapComponent } from './components/gmap/gmap.component';
import { AgmCoreModule } from '@agm/core';
@NgModule({
  imports: [
    CommonModule,
    ContactsRoutingModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyA2yyLfHeQrZecnot_R0N3dkvXzKUmaD4Q'
    })
  ],
  declarations: [ContactsComponent, GmapComponent]
})
export class ContactsModule { }
