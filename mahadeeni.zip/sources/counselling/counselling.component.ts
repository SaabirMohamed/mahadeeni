import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { AngularFirestore, AngularFirestoreDocument, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Page, CousellingPage } from '../../shared/page.model';

@Component({
  selector: 'app-counselling',
  templateUrl: './counselling.component.html',
  styleUrls: ['./counselling.component.scss']
})
export class CounsellingComponent implements OnInit {
  counsellingpageData: CousellingPage = null;
  constructor(private afs: AngularFirestore) { }

  ngOnInit() {
    const collection = this.afs.collection('modules').doc('counsellingpage').valueChanges();
    collection.subscribe((data: CousellingPage) => {
      this.counsellingpageData = data;
      console.log(this.counsellingpageData);
  });
  }

}
