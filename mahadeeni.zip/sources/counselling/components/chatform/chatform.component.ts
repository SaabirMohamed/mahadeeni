import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatform',
  templateUrl: './chatform.component.html',
  styleUrls: ['./chatform.component.scss']
})
export class ChatformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
