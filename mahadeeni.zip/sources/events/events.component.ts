import { Component, OnInit } from '@angular/core';
// import { AngularFirestore } from 'angularfire2/firestore';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss']
})
export class EventsComponent implements OnInit {

  // constructor(private afs: AngularFirestore) { }
  rsvp: boolean;
  ngOnInit() {
    // this.afs.collection('homepage/events');
    this.rsvp = false;
  }

  showrsvp() {
    this.rsvp = !this.rsvp;
  }

}
