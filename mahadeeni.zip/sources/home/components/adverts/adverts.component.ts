import { Component, OnInit } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adverts',
  templateUrl: './adverts.component.html',
  styleUrls: ['./adverts.component.scss']
})
export class AdvertsComponent implements OnInit {

  articlesCollection: AngularFirestoreCollection<IArticle>;
  $articlesCollection: IArticle[];
  constructor(private router: Router, private afs: AngularFirestore) { }
  lefty: boolean;
  righty: boolean;

  ngOnInit() {
    this.getArticles();
  }

  Navigate(path: string) {
    this.router.navigateByUrl(path);
  }
  public getArticles() {
    this.articlesCollection = this.afs.collection('modules/homepage/articles');
    this.articlesCollection.valueChanges().subscribe((data) => {
      this.$articlesCollection = data;
      console.log(this.$articlesCollection);
      for (let i = 0; i < this.$articlesCollection.length; i++) {
         if (i / 2 === 0 ) {
          this.lefty = true;
          this.righty = false;
         } else {
           this.righty = true;
         }
      }
    });
  }




}

export interface IArticle {
  articleTitle: string;
  articleSubTile: string;
  articleImage: string;
  
}
