import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';


@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.scss']
})
export class BlogComponent implements OnInit {
  articlefile: string;
  constructor(private san: DomSanitizer) { }

  ngOnInit() {
  }

   showArticle(num: any) {
    const sanned = this.san.bypassSecurityTrustHtml(num);
    this.articlefile = 'https://docs.google.com/gview?url=http://www.mahadeeni.co.za/assets/article' + sanned + '.doc&embedded=true';
   }


}
