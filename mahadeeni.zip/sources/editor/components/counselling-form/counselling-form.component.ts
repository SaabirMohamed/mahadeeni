import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { FsService } from '../../../../shared/fs.service';
import { Page } from '../../../../shared/page.model';

@Component({
  selector: 'app-counselling-form',
  templateUrl: './counselling-form.component.html',
  styleUrls: ['./counselling-form.component.scss']
})
export class CounsellingFormComponent implements OnInit {
  currentFileName = null;
  dociId = 'counsellingpage';
  colId = 'modules';
  pageTitleForm: FormGroup;
  pageSubTitleForm: FormGroup;
  appointmentImageForm: FormGroup;
  messageImageForm: FormGroup;
  chatImageForm: FormGroup;
  payload: any;
  appointmentFileName: 'defaultlogo.png';
  messageFileName: 'defaultlogo.png';
  chatFileName: 'defaultlogo.png';
  appointmentFileToUpload: File;
  messageFileToUpload: File;
  chatFileToUpload: File;
  outgoingPayload: any;

  constructor(private fbsvc: FsService, public fbuilder: FormBuilder) {
    this.pageTitleForm = this.fbuilder.group({
      pageTitle: ['', Validators.required]
    });

    this.pageSubTitleForm = this.fbuilder.group({
      pageSubTitle: ['', Validators.required]
    });

    this.appointmentImageForm = this.fbuilder.group({
      appointmentImage: ['', Validators.required]
    });
    this.chatImageForm = this.fbuilder.group({
      chatImage: ['', Validators.required]
    });
    this.messageImageForm = this.fbuilder.group({
      messageImage: ['', Validators.required]
    });

   }

  ngOnInit() {

  }

  updateTitle(val) {
    document.getElementById('titleBtn').setAttribute('style', 'opacity:0');
      if (val !== '') {
        const payload = {
          pageTitle : val
        };
        // this.fbsvc.updateDocument('modules', 'homepage', <Page>payload) (testing)
        this.fbsvc.updateDocument(this.colId, this.dociId, <Page>payload)
        .then((data) => {
                this.pageTitleForm.reset();
                document.getElementById('titleBtn').setAttribute('style', 'opacity:1');
              })
        .catch((error) => console.log(error));
      }
  }

  updateSubTitle(val) {
    document.getElementById('subtitleBtn').setAttribute('style', 'opacity:0');
    if (val !== '') {
     const payload = {
      pageSubTitle : val
    };
    // this.fbsvc.updateDocument('modules', 'homepage', <Page>payload)
    this.fbsvc.updateDocument(this.colId, this.dociId, <Page>payload)
    .then(data => {
      this.pageSubTitleForm.reset();
      document.getElementById('subtitleBtn').setAttribute('style', 'opacity:1');
    } )
    .catch((error) => console.log(error));
  }
}

  updatePageImage() {
    if (this.appointmentFileName) {
        document.getElementById('uploadBtn').setAttribute('style', 'opacity:0');
        this.sendImage(this.appointmentFileName, 'appointment', this.appointmentFileToUpload);
    }
    if (this.messageFileName) {
      document.getElementById('uploadBtn2').setAttribute('style', 'opacity:0');
        this.sendImage(this.messageFileName, 'message', this.messageFileToUpload);
    }
    if (this.chatFileName) {
      document.getElementById('uploadBtn3').setAttribute('style', 'opacity:0');
        this.sendImage(this.messageFileName, 'chat', this.chatFileToUpload);
    }
  }

  ProcessFile(event, forwhat: string) {
    if (forwhat === 'appointment') {
    console.log(event.target.files[0].name);
    this.appointmentFileName = event.target.files[0].name;
    this.appointmentFileToUpload = event.target.files[0];
    }
    if (forwhat === 'message') {
      console.log(event.target.files[0].name);
      this.messageFileName = event.target.files[0].name;
      this.messageFileToUpload = event.target.files[0];
    }
    if (forwhat === 'chat') {
      console.log(event.target.files[0].name);
      this.chatFileName = event.target.files[0].name;
      this.chatFileToUpload = event.target.files[0];
    }
  }

  uploadToServer(file: File) {
    console.log('will be uploading this: ' + this.appointmentFileToUpload);
    this.fbsvc.AddToServerAssets(file);
  }

  sendImage(filename: string, targetName: string, file: File) {
    if ( targetName === 'appointment' ) {
      this.outgoingPayload = {
        appointmentImage : filename
      };
    }
    if ( targetName === 'message' ) {
      this.outgoingPayload = {
        messageImage : filename
      };
    }
    if ( targetName === 'chat' ) {
      this.outgoingPayload = {
        chatImage : filename
      };
    }
    this.uploadToServer(file);
    console.log('OUTGOING PAYLOAD:' + this.outgoingPayload);
    this.fbsvc.updateDocument('modules', 'counsellingpage', this.outgoingPayload)
    .then(data => {
      document.getElementById('uploadBtn').setAttribute('style', 'opacity:1');
      document.getElementById('uploadBtn2').setAttribute('style', 'opacity:1');
      document.getElementById('uploadBtn3').setAttribute('style', 'opacity:1');

      this.appointmentImageForm.reset();
      this.chatImageForm.reset();
      this.messageImageForm.reset();
      this.appointmentFileName = null;
      this.messageFileName = null;
      this.chatFileName = null;
    })
    .catch((error) => console.log(error));
  }

}
