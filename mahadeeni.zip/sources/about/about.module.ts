import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AboutRoutingModule } from './about-routing.module';
import { AboutComponent } from './about.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

@NgModule({
  imports: [
    CommonModule,
    AboutRoutingModule,
    MDBBootstrapModule.forRoot()
  ],
  declarations: [AboutComponent]
})
export class AboutModule { }
