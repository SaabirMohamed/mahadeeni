import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslationsRoutingModule } from './translations-routing.module';
import { TranslationsComponent } from './translations.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

@NgModule({
  imports: [
    CommonModule,
    TranslationsRoutingModule,
    MDBBootstrapModule.forRoot()
  ],
  declarations: [TranslationsComponent]
})
export class TranslationsModule { }
