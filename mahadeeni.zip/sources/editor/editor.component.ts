import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.scss']
})
export class EditorComponent implements OnInit {
  uname: string;
  homeOn: boolean;
  articlesOn: boolean;
  counsellingOn: boolean;
  aboutOn: boolean;
  schoolOn: boolean;
  contactsOn: boolean;
  constructor(private router: Router) { }

  ngOnInit() {
    this.uname = localStorage.getItem('uname');
    if (!this.uname) {
        this.router.navigateByUrl('/login');
    }
  }

  homeToggle() {
    this.turnAlloff();
    this.homeOn = !this.homeOn;
  }
  articlesToggle() {
    this.turnAlloff();
    this.articlesOn = !this.articlesOn;
  }
  aboutToggle() {
    this.turnAlloff();
    this.aboutOn = !this.aboutOn;
  }
  contactsToggle() {
    this.turnAlloff();
    this.contactsOn = !this.contactsOn;
  }
  counsellingToggle() {
    this.turnAlloff();
    this.counsellingOn = !this.counsellingOn;
  }
  schoolToggle() {
    this.turnAlloff();
    this.schoolOn = !this.schoolOn;
  }
  turnAlloff() {
    this.homeOn = false;
    this.contactsOn = false;
    this.counsellingOn = false;
    this.aboutOn = false;
    this.articlesOn = false;
    this.schoolOn = false;
  }
}
