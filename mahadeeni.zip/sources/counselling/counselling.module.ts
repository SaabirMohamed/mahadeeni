import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MyglobalsModule} from '../../shared/myglobals.module';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { CounsellingRoutingModule } from './counselling-routing.module';
import { CounsellingComponent } from './counselling.component';
import { AppointmentformComponent } from './components/appointmentform/appointmentform.component';
import { SendmessageformComponent } from './components/sendmessageform/sendmessageform.component';
import { ChatformComponent } from './components/chatform/chatform.component';


@NgModule({
  imports: [
    CommonModule,
    MyglobalsModule,
    CounsellingRoutingModule,
    MDBBootstrapModule.forRoot()
  ],
  declarations: [CounsellingComponent, AppointmentformComponent, SendmessageformComponent, ChatformComponent]
})
export class CounsellingModule { }
